TARGET_CLASSES = {
    0: "Locust (Schistocerca gregaria) - Harmful",
    1: "Armyworm (Spodoptera frugiperda) - Harmful",
    2: "Earwig (Dermaptera) - Beneficial",
    3: "Honeybee (Apis mellifera) - Beneficial",
};